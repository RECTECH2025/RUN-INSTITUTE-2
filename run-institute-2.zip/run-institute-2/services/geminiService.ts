import { GoogleGenAI, Type, Schema } from "@google/genai";
import { CourseData, MarketingPlanResponse } from "../types";

export const generateMarketingPlan = async (
  courseData: CourseData, 
  targetDate: string
): Promise<MarketingPlanResponse> => {
  
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set REACT_APP_GEMINI_API_KEY or check your environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const contextPrompt = `
    You are an expert Social Media Strategist specializing in educational programs and female leadership empowerment.
    
    Here is the detailed information about the course "Programa Liderazgo Femenino" by Run Institute:
    Title: ${courseData.title}
    Subtitle: ${courseData.subtitle}
    Target Audience: ${courseData.targetAudience}
    Key Pain Points (Questions): ${courseData.keyQuestions.join(", ")}
    Key Stats: ${courseData.statistics.join(" ")}
    Modules: ${courseData.modules.map(m => m.title).join(", ")}
    Price: ${courseData.price}
    Facilitators: ${courseData.facilitators.map(f => f.name).join(", ")}
    Values: Empowerment, Self-awareness, Productivity, Efficiency.
    
    TASK:
    Create a highly engaging, conversion-focused Social Media Content Calendar (Instagram & Facebook).
    The goal is to sell this course with a launch deadline of: ${targetDate}.
    
    REQUIREMENTS:
    1.  Create a 4-week intensive content plan leading up to the launch.
    2.  Mix of Reels (Short Video), Carousels (Educational), and Static Posts (Social Proof/Quotes).
    3.  Tone: Empowering, professional, empathetic, yet urgent.
    4.  Include specific visual prompts and caption hooks.
    5.  Include a brief 'strategyOverview' paragraph explaining the approach.
  `;

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      strategyOverview: { type: Type.STRING, description: "A summary of the marketing strategy." },
      posts: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            week: { type: Type.INTEGER, description: "Week number (1-4)" },
            day: { type: Type.INTEGER, description: "Day number within the week (1-7)" },
            title: { type: Type.STRING, description: "Internal title of the post" },
            platform: { type: Type.STRING, enum: ["Instagram", "Facebook", "IG & FB"] },
            type: { type: Type.STRING, enum: ["Reel (Short Video)", "Carousel", "Static Post", "Story"] },
            hook: { type: Type.STRING, description: "The first 3 seconds or first line text" },
            contentDescription: { type: Type.STRING, description: "Detailed description of visual content or video script" },
            caption: { type: Type.STRING, description: "The full caption text including emojis" },
            hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            visualPrompt: { type: Type.STRING, description: "Instruction for the designer or video editor" }
          },
          required: ["week", "day", "title", "platform", "type", "hook", "contentDescription", "caption", "hashtags", "visualPrompt"]
        }
      }
    },
    required: ["strategyOverview", "posts"]
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contextPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        systemInstruction: "You are a world-class digital marketer. Always output valid JSON matching the schema.",
        temperature: 0.7
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    return JSON.parse(text) as MarketingPlanResponse;

  } catch (error) {
    console.error("Error generating plan:", error);
    throw error;
  }
};