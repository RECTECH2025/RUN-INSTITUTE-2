import React, { useState } from 'react';
import { MarketingPlanResponse, MarketingPost, ContentType } from '../types';
import { Instagram, Facebook, Video, Image, Layers, Copy, Check } from 'lucide-react';

interface Props {
  plan: MarketingPlanResponse;
}

const PlanDisplay: React.FC<Props> = ({ plan }) => {
  const [activeWeek, setActiveWeek] = useState<number>(1);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const postsByWeek = plan.posts.reduce((acc, post) => {
    if (!acc[post.week]) acc[post.week] = [];
    acc[post.week].push(post);
    return acc;
  }, {} as Record<number, MarketingPost[]>);

  const weeks = Object.keys(postsByWeek).map(Number).sort((a, b) => a - b);

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const getTypeIcon = (type: string) => {
    if (type.includes('Reel')) return <Video className="w-4 h-4 text-pink-600" />;
    if (type.includes('Carousel')) return <Layers className="w-4 h-4 text-blue-600" />;
    return <Image className="w-4 h-4 text-green-600" />;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-full flex flex-col overflow-hidden">
      {/* Header Strategy */}
      <div className="p-6 border-b border-slate-100 bg-slate-50">
        <h2 className="text-xl font-bold text-run-dark mb-2">Estrategia de Lanzamiento</h2>
        <p className="text-slate-600 text-sm leading-relaxed">{plan.strategyOverview}</p>
      </div>

      {/* Week Selector */}
      <div className="flex border-b border-slate-200 bg-white sticky top-0 z-10">
        {weeks.map((week) => (
          <button
            key={week}
            onClick={() => setActiveWeek(week)}
            className={`flex-1 py-4 text-sm font-bold text-center transition-colors border-b-2 ${
              activeWeek === week
                ? 'border-run-pink text-run-pink bg-pink-50'
                : 'border-transparent text-slate-500 hover:text-run-dark hover:bg-slate-50'
            }`}
          >
            Semana {week}
          </button>
        ))}
      </div>

      {/* Posts List */}
      <div className="overflow-y-auto flex-1 p-6 space-y-6 bg-slate-50/50">
        {postsByWeek[activeWeek]?.map((post, index) => (
          <div key={index} className="bg-white rounded-lg border border-slate-200 shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
            {/* Post Header */}
            <div className="flex items-center justify-between p-4 bg-slate-50 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <span className="bg-run-dark text-white text-xs font-bold px-2 py-1 rounded">
                  Día {post.day}
                </span>
                <div className="flex items-center gap-2 text-slate-500 text-sm">
                   {getTypeIcon(post.type)}
                   <span className="font-medium">{post.type}</span>
                </div>
              </div>
              <div className="flex gap-2 text-slate-400">
                {post.platform.includes('Instagram') && <Instagram className="w-4 h-4" />}
                {post.platform.includes('Facebook') && <Facebook className="w-4 h-4" />}
              </div>
            </div>

            <div className="p-5 space-y-4">
              {/* Title & Hook */}
              <div>
                <h3 className="text-lg font-bold text-run-dark mb-1">{post.title}</h3>
                <div className="bg-pink-50 border-l-4 border-pink-500 p-3 rounded-r">
                  <p className="text-xs font-bold text-pink-700 uppercase mb-1">Hook / Gancho</p>
                  <p className="text-slate-800 font-medium italic">"{post.hook}"</p>
                </div>
              </div>

              {/* Visual Description */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Contenido Visual / Guion</h4>
                    <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded border border-slate-100 h-full">
                        {post.contentDescription}
                    </p>
                 </div>
                 
                 {/* Visual Prompt */}
                 <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Instrucción de Diseño</h4>
                    <p className="text-sm text-slate-500 italic bg-slate-50 p-3 rounded border border-slate-100 h-full">
                        {post.visualPrompt}
                    </p>
                 </div>
              </div>

              {/* Caption */}
              <div className="relative group">
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Copy / Caption sugerido</h4>
                <div className="bg-slate-900 text-slate-300 p-4 rounded-lg text-sm font-mono whitespace-pre-wrap leading-relaxed relative">
                  {post.caption}
                  
                  <div className="mt-4 text-pink-400 text-xs">
                    {post.hashtags.map(tag => tag.startsWith('#') ? tag : `#${tag}`).join(' ')}
                  </div>

                  {/* Copy Button */}
                  <button
                    onClick={() => copyToClipboard(`${post.caption}\n\n${post.hashtags.map(t => '#' + t.replace('#','')).join(' ')}`, index)}
                    className="absolute top-2 right-2 p-2 bg-slate-800 rounded hover:bg-slate-700 text-white transition-colors"
                    title="Copiar Caption"
                  >
                    {copiedIndex === index ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlanDisplay;