import React from 'react';
import { CourseData } from '../types';
import { BookOpen, Users, HelpCircle, TrendingUp, Award } from 'lucide-react';

interface Props {
  data: CourseData;
}

const CourseInfo: React.FC<Props> = ({ data }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-full flex flex-col">
      <div className="bg-run-dark p-6 text-white">
        <h2 className="text-2xl font-bold">{data.title}</h2>
        <p className="text-run-pink font-semibold mt-1">{data.subtitle}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="bg-run-pink/20 text-run-pink px-3 py-1 rounded-full text-xs font-bold border border-run-pink">
            {data.price}
          </span>
          <span className="bg-slate-700 px-3 py-1 rounded-full text-xs text-gray-300">
            {data.duration}
          </span>
        </div>
      </div>

      <div className="p-6 overflow-y-auto space-y-8 flex-1">
        {/* Target Audience */}
        <section>
          <div className="flex items-center gap-2 mb-3 text-run-dark">
            <Users className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wide text-sm">Audiencia & Objetivo</h3>
          </div>
          <p className="text-slate-600 text-sm leading-relaxed border-l-4 border-run-gold pl-3">
            {data.targetAudience}
          </p>
        </section>

        {/* Key Questions */}
        <section>
          <div className="flex items-center gap-2 mb-3 text-run-dark">
            <HelpCircle className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wide text-sm">Puntos de Dolor</h3>
          </div>
          <ul className="space-y-2">
            {data.keyQuestions.slice(0, 4).map((q, idx) => (
              <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                <span className="text-run-pink font-bold">•</span>
                {q}
              </li>
            ))}
          </ul>
        </section>

        {/* Modules */}
        <section>
          <div className="flex items-center gap-2 mb-3 text-run-dark">
            <BookOpen className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wide text-sm">Módulos Clave</h3>
          </div>
          <div className="grid grid-cols-1 gap-2">
            {data.modules.slice(0, 5).map((m) => (
              <div key={m.id} className="bg-slate-50 p-2 rounded text-xs text-slate-700 font-medium">
                 {m.id}. {m.title}
              </div>
            ))}
            <div className="text-center text-xs text-slate-400 italic">
              + {data.modules.length - 5} módulos más...
            </div>
          </div>
        </section>

        {/* Statistics */}
        <section>
          <div className="flex items-center gap-2 mb-3 text-run-dark">
            <TrendingUp className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wide text-sm">Datos de Mercado</h3>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
             <p className="text-blue-900 text-sm italic">"{data.statistics[0]}"</p>
          </div>
        </section>
        
        {/* Testimonials */}
         <section>
          <div className="flex items-center gap-2 mb-3 text-run-dark">
            <Award className="w-5 h-5" />
            <h3 className="font-bold uppercase tracking-wide text-sm">Testimonio Destacado</h3>
          </div>
          <div className="bg-run-pink/5 p-4 rounded-lg border border-run-pink/20">
             <p className="text-slate-700 text-sm italic mb-2">"{data.testimonials[0].text}"</p>
             <p className="text-run-pink text-xs font-bold text-right">- {data.testimonials[0].name}</p>
          </div>
        </section>

      </div>
    </div>
  );
};

export default CourseInfo;